<?php

session_start();
?>
<?php

if(isset($_POST['age']) && isset($_POST['nom'])){
$age = $_POST["age"] ;
$nom = $_POST["nom"];
}else{
    echo "success" ;
}

?>

<?php
try
{
$bdd = new PDO('mysql:host=localhost;dbname=lsi1;charset=utf8', 'root', '');
if(isset($_POST['age']) && isset($_POST['nom'])){
    $tab = $bdd->query('SELECT * FROM étudiant');

// insert into bdd table etudiant

$req = $bdd->prepare('INSERT INTO étudiant(nom, age ) VALUES(:nom, :age )');

$req->execute(array( 'nom' => $nom,
'age' => $age

));
}else{
    $tab = $bdd->query('SELECT * FROM étudiant');
    echo " ";
}


}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
?>
<html>
<head>
<title>lsi</title>
</head>
<body>
<table>
<th>id</th>
<th>nom</th>
<th>age</th>
<?php
$tab = $bdd->query('SELECT * FROM étudiant');
while ($donnees = $tab->fetch()){
?>
<?php $_SESSION["ageee"]=$donnees['age'];$_SESSION["nommm"]=$donnees['nom']; ?>
<tr>
<td><?php echo $donnees['id']; ?></td>
<td><?php echo $donnees['nom']; ?></td>
<td><?php echo $donnees['age']; ?></td>
<td><?php echo "<form method='post' action='supprimier.php'> <button name='remove' type='submit' value= '". $donnees['id'] ."'  >Supprimer</button></form>"?></td>
<td><?php echo "<form method='post' action='modifier.php'> <button name='modifier' type='submit' value= '". $donnees['id'] ."'  >modifier</button></form>"?></td>
</tr>
<?php
}
?>
</table>

</body>


</html>