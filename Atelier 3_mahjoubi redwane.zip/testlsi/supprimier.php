<?php

session_start();
?>

<?php
try
{
$bdd = new PDO('mysql:host=localhost;dbname=lsi1;charset=utf8', 'root', '');
    $tab = $bdd->query('SELECT * FROM étudiant');

}
catch (Exception $e)
{
die('Erreur : ' . $e->getMessage());
}
if(isset($_POST['remove'])){
    $remo = $bdd->prepare("DELETE FROM étudiant WHERE id= :id");
    $getid=$_POST['remove'];
    $remo->bindparam("id",$getid);
    $remo->execute() ;
    }
?>
<html>
<head>
<title>lsi</title>
</head>
<body>
<table>
<th>id</th>
<th>nom</th>
<th>age</th>
<?php
 $tab = $bdd->query('SELECT * FROM étudiant');
while ($donnees = $tab->fetch()){
?>

<tr>
<td><?php echo $donnees['id']; ?></td>
<td><?php echo $donnees['nom']; ?></td>
<td><?php echo $donnees['age']; ?></td>
<td><?php echo "<form method='post'> <button name='remove' type='submit' value= '". $donnees['id'] ."'  >Supprimer</button></form>"?></td>
<td><?php echo "<form method='post' action='modifier.php'> <button name='modifier' type='submit' value= '". $donnees['id'] ."'  >modifier</button></form>"?></td>
</tr>

<?php
}
?>
</table>

</body>


</html>