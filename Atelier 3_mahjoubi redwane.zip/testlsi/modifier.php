
<?php
session_start();
$_SESSION["pannn"]="good for you" ;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
$getiddd=$_POST['modifier'];
$ageee=$_SESSION["ageee"];
$nommm=$_SESSION["nommm"];
?>
<form action="modifier2.php" method="post">

<label >age</label>
<input type="text" name="agee" id="age" value='<?php echo " $ageee "?>' > <br>

<label >NOM</label>
<input type="text" name="nomm" id="nom" value='<?php echo " $nommm "?>' ><br>

<?php echo "<form method='post' action='modifier2.php'> <button name='modifier2' type='submit' value= '". $getiddd ."'  >modifier</button></form>"?></td>

</form>




</body>
</html>